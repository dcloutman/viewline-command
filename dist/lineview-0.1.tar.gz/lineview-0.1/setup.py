from setuptools import setup, find_packages

setup(
    name="lineview",
    version="0.01",
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "lineview=bin.lineview:main",
        ],
    },
    install_requires=[],
    description="A command-line tool to display specific lines from a file or stream.",
    author="dcloutman",
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
