from lib.lineview import lineview_impl, is_file_binary
